<?php
/** News block **/

if(!class_exists('AQ_News_Block')) {
	class AQ_News_Block extends AQ_Block {
		
		//set and create block
		function __construct() {
			$block_options = array(
				'name' => 'Latest News',
				'size' => 'span6',
			);
			
			//create the block
			parent::__construct('aq_news_block', $block_options);
		}
		
		function form($instance) {
			
			$defaults = array(
				'post_number' => '5',
				'post_order' => '',
				'order_by' => '',
				'category' => '',
			);

			$instance = wp_parse_args($instance, $defaults);
			extract($instance);

            $args = array(
                'type'                     => 'post',
                'child_of'                 => 0,
                'parent'                   => '',
                'orderby'                  => 'name',
                'order'                    => 'ASC',
                'hide_empty'               => 1,
                'hierarchical'             => 1,
                'exclude'                  => '',
                'include'                  => '',
                'number'                   => '',
                'taxonomy'                 => 'category',
                'pad_counts'               => false

            );
            $categories = get_categories( $args );
            $category_options = array('-1' => 'All Categories');

            foreach($categories as $one_category){
                $category_options = $category_options + array($one_category->term_id => $one_category->name);
            }

			$order_options = array(
				'ASC' => 'Ascending',
				'DESC' => 'Descending',
			);

            $order_by_options = array(
                'ID' => 'Order by Post ID',
                'author' => 'Order by Post author',
                'title' => 'Order by Post title',
                'name' => 'Order by Post name (slug)',
                'date' => 'Order by Post Date',
                'modified' => 'Order by Post Modified Date',
                'comment_count' => 'Order by number of comments',
                'rand' => 'Random order',
            );
			?>
			
            <p class="description">
                    <label for="<?php echo $this->get_field_id('title') ?>">
                            Title<br/>
                            <?php echo aq_field_input('title', $block_id, $title) ?>
                    </label>
            </p>
            <p class="description">
                <label for="<?php echo $this->get_field_id('post_number') ?>">
                    Number of posts<br/>
                    <?php echo aq_field_input('post_number', $block_id, $post_number) ?>
                </label>
            </p>
            <p class="description half">
                <label for="<?php echo $this->get_field_id('category') ?>">
                    Select Category<br/>
                    <?php echo aq_field_select('category', $block_id, $category_options, $category) ?>
                </label>
            </p>
            <p class="description half">
                <label for="<?php echo $this->get_field_id('order_by') ?>">
                    Order By<br/>
                    <?php echo aq_field_select('order_by', $block_id, $order_by_options, $order_by) ?>
                </label>
            </p>
			<p class="description half">
				<label for="<?php echo $this->get_field_id('post_order') ?>">
					Ordering Type<br/>
					<?php echo aq_field_select('post_order', $block_id, $order_options, $post_order) ?>
				</label>
			</p>

			<?php
			
		}
		
        function block($instance) {
            extract($instance);
            if($category == '-1'){
                $get_page_id = get_option('id_blog_page');
                if(isset($get_page_id)){
                    $category_link = get_permalink($get_page_id);
                }else{
                    $category_link = '#';
                }
            }else{
                $category_link = get_category_link( $category );
            }
            
            $prefix = "tk_";
            
            ?>
            <div class="">
                <?php if(!empty($title)){?>
                    <div class="title-holder margin-bottom-45">
                        <h2 class="title-divider">
                            <span><?php echo $title?></span>
                        </h2>
                    </div>
                <?php }?>
                <div class="clear"></div>
                <?php
               
                if($category == '-1'){ 
                    $args = array('post_status' => 'publish', 'post_type' => 'post', 'posts_per_page' => $post_number );
                }else{
                    $args = array('cat' => $category, 'post_status' => 'publish', 'post_type' => 'post', 'posts_per_page' => $post_number, 'orderby' => $order_by, 'order' => $post_order );
                }
                    // The Query
                
                    $the_query = new WP_Query($args);
                    if ($the_query->have_posts()): while ($the_query->have_posts()) : $the_query->the_post(); ?>
                        <?php
                        $attachments  = get_post_meta($the_query->post->ID, 'tk_repeatable', true);
                        $video_link = get_post_meta($the_query->post->ID, 'tk_video_link', true);
                        ?>
                        <div class="news-wrap margin-bottom-builder left">
                            <?php if (get_post_format() == 'audio') {?>

                                <div class="span12 margin-left-0">
                                    <div class="row-fluid home-audio-player">
                                        <?php // check if link to audio file exists
                                        $audio_link = get_post_meta($the_query->post->ID, 'tk_audio_link', true);
                                        if($audio_link){?>
                                            <div class="row-fluid blog-player">
                                                <?php tk_jplayer($the_query->post->ID); ?>
                                                <div id="jquery_jplayer_<?php echo $the_query->post->ID ?>" class="jp-jplayer"></div>
                                                <div id="jp_container_<?php echo $the_query->post->ID ?>" class="jp-audio">
                                                    <div class="jp-type-single">
                                                        <div class="jp-gui jp-interface" id="jp_interface_<?php echo $the_query->post->ID; ?>">
                                                            <ul class="jp-controls">
                                                                <li><a href="javascript:;" class="jp-play" tabindex="1">play</a></li>
                                                                <li><a href="javascript:;" class="jp-pause" tabindex="1">pause</a></li>
                                                                <li><a href="javascript:;" class="jp-mute" tabindex="1" title="mute">mute</a></li>
                                                                <li><a href="javascript:;" class="jp-unmute" tabindex="1" title="unmute">unmute</a></li>
                                                            </ul>
                                                            <div class="jp-progress">
                                                                <div class="jp-seek-bar">
                                                                    <div class="jp-play-bar"></div>
                                                                </div>
                                                            </div>
                                                            <div class="jp-volume-bar">
                                                                <div class="jp-volume-bar-value"></div>
                                                            </div>
                                                        </div><!--/jp-gui jp-interface-->
                                                    </div><!--/jp-type-single-->
                                                </div><!--/jp-audio-->
                                            </div>
                                            <!--/blog-player-->
                                        <?php }?>
                                    </div>
                                    <div class="row-fluid blog-audio-info">
                                        <a href="<?php the_permalink()?>"><?php the_title()?></a>
                                    </div>
                                    <div class="clear"></div>
                                    <div class="top-content-text">
                                        <p><?php the_excerpt()?></p>
                                        <ul>
                                            <li><img src="<?php echo get_template_directory_uri()?>/img/user-icon.png"><p><?php the_author_posts_link();?></p></li>
                                            <li><img src="<?php echo get_template_directory_uri()?>/img/calendar-icon.png"><p><?php echo get_the_date() ?></p></li>
                                            <li><img src="<?php echo get_template_directory_uri()?>/img/charity-icon.png"><p><?php echo get_the_category_list(', ', $the_query->post->ID); ?></p></li>
                                        </ul>
                                        <a href="<?php the_permalink()?>"><?php _e('Read More', 'tkingdom')?><i class="plas10"><div class="plus-up"></div><div class="plus-hor"></div></i></a>
                                    </div>
                                </div>
                            <?php } elseif (get_post_format() == 'quote') {
                                    $quote_text = get_post_meta($the_query->post->ID, $prefix.'quote', true);
                                    $quote_author = get_post_meta($the_query->post->ID, $prefix.'quote_author', true);   
                                ?>
                                <div class="span12">
                                    <div class="row-fluid">
                                        <div class="span2">
                                            <img src="<?php echo get_template_directory_uri()?>/img/quote-post.jpg">
                                        </div>
                                        <div class="span10">
                                            <div class="top-content-text">

                                                <h3><a href="<?php the_permalink(); ?>"><?php echo $quote_text; ?></a></h3>                        
                                                <div class="link-post">
                                                    <?php echo $quote_author; ?>
                                                </div><!-- link-post -->    

                                                <ul>
                                                    <li><img src="<?php echo get_template_directory_uri()?>/img/user-icon.png"><p><?php the_author_posts_link();?></p></li>
                                                    <li><img src="<?php echo get_template_directory_uri()?>/img/calendar-icon.png"><p><?php echo get_the_date() ?></p></li>
                                                    <li><img src="<?php echo get_template_directory_uri()?>/img/charity-icon.png"><p><?php echo get_the_category_list(', ', $the_query->post->ID); ?></p></li>
                                                </ul>
                                                <a href="<?php the_permalink()?>"><?php _e('Read More', 'tkingdom')?><i class="plas10"><div class="plus-up"></div><div class="plus-hor"></div></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            <?php }elseif (get_post_format() == 'link') {
                                    $link_text = get_post_meta($the_query->post->ID , $prefix.'link_text', true);
                                    $link_url = get_post_meta($the_query->post->ID , $prefix.'link_url', true);                                   
                                ?>

                                <div class="span12 margin-left-0">
                                    <div class="row-fluid">
                                        <div class="span2">
                                            <img src="<?php echo get_template_directory_uri()?>/img/link-post.jpg">
                                        </div>
                                        <div class="span10">
                                            <div class="top-content-text">

                                                <h3><a href="<?php  echo $link_url; ?>" title="<?php the_title();?>"><?php the_title(); ?></a></h3>                        
                                                <div class="link-post">
                                                    <a href="<?php echo $link_url; ?>"><?php echo $link_text; ?></a>
                                                </div><!-- link-post -->      

                                                <ul>
                                                    <li><img src="<?php echo get_template_directory_uri()?>/img/user-icon.png"><p><?php the_author_posts_link();?></p></li>
                                                    <li><img src="<?php echo get_template_directory_uri()?>/img/calendar-icon.png"><p><?php echo get_the_date() ?></p></li>
                                                    <li><img src="<?php echo get_template_directory_uri()?>/img/charity-icon.png"><p><?php echo get_the_category_list(', ', $the_query->post->ID); ?></p></li>
                                                </ul>                                            
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            <?php }else{?>
                            <div class="span12 margin-left-0">
                                <a href="<?php the_permalink()?>" class="image-relative">
                                    <?php if (get_post_format() == 'video') {?>
                                        <?php if($video_link){?>
                                            <?php tk_video_player($video_link);?>
                                        <?php }?>
                                    <?php } elseif (get_post_format() == 'gallery') {?>
                                        <?php if(!empty ($attachments[0])){?>
                                            <div class="flexslider">
                                                <ul class="slides">
                                                    <?php
                                                    foreach($attachments as $attach) {
                                                        echo '<li><img src="'.tk_get_thumb(770, 398, $attach).'" /></li>';
                                                    }
                                                    ?>
                                                </ul>
                                            </div><!-- flex slider -->
                                        <?php }?>
                                    <?php }else {?>
                                        <?php if(has_post_thumbnail()){?>
                                        <?php                                     
                                            //checks to see what size is selected and chooses thumbnail size
                                            if($instance['size'] == 'span12' || $instance['size'] == 'span11' || $instance['size'] == 'span10' || $instance['size'] == 'span9' || $instance['size'] == 'span8' || $instance['size'] == 'span7' || $instance['size'] == 'span7'){
                                                the_post_thumbnail('home-events-full');
                                            } else {
                                                the_post_thumbnail('home-events');
                                            } 
                                        }?>
                                    <?php }?>
                                    <ul class="home-meta-ul">
                                        <li>
                                            <p><?php the_title()?></p>
                                        </li>
                                    </ul>
                                </a>
                                <div class="clear"></div>
                                <div class="top-content-text">
                                    <p><?php the_excerpt()?></p>
                                    <ul>
                                        <li><img src="<?php echo get_template_directory_uri()?>/img/user-icon.png"><p><?php the_author_posts_link();?></p></li>
                                        <li><img src="<?php echo get_template_directory_uri()?>/img/calendar-icon.png"><p><?php echo get_the_date() ?></p></li>
                                        <li><img src="<?php echo get_template_directory_uri()?>/img/charity-icon.png"><p><?php echo get_the_category_list(', ', $the_query->post->ID); ?></p></li>
                                    </ul>
                                    <a href="<?php the_permalink()?>"><?php _e('Read More', 'tkingdom')?><i class="plas10"><div class="plus-up"></div><div class="plus-hor"></div></i></a>
                                </div>
                            </div>
                            <?php }?>
                        </div><!-- news-wrap -->
                    <div class="clear"></div>

                    <?php endwhile; ?>
                <?php endif;?>
            </div>
        <?php
		}
		
	}
}