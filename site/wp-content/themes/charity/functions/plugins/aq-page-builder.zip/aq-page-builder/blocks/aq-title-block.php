<?php
/** Events block **/

if(!class_exists('AQ_Title_Block')) {
    class AQ_Title_Block extends AQ_Block {

        //set and create block
        function __construct() {
            $block_options = array(
                'name' => 'Title',
                'size' => 'span6',
            );

            //create the block
            parent::__construct('aq_title_block', $block_options);
        }

        function form($instance) {

            $defaults = array(
                'link_title' => '',
                'link_url' => '',
                'link_text' => ''
            );


            $instance = wp_parse_args($instance, $defaults);
            extract($instance);
            ?>

            <p class="description">
                <label for="<?php echo $this->get_field_id('link_title') ?>">
                    Title<br/>
                    <?php echo aq_field_input('link_title', $block_id, $link_title) ?>
                </label>
            </p>
            <p class="description">
                <label for="<?php echo $this->get_field_id('link_url') ?>">
                    Custom Link<br/>
                    <?php echo aq_field_input('link_url', $block_id, $link_url) ?>
                </label>
            </p>
            <p class="description">
                <label for="<?php echo $this->get_field_id('link_text') ?>">
                    Custom Link Text<br/>
                    <?php echo aq_field_input('link_text', $block_id, $link_text) ?>
                </label>
            </p>

        <?php

        }

        function block($instance) {
            extract($instance);?>
            <div class="row-fluid margin-0">
                <?php if(!empty($link_title)){?>
                    <div class="title-holder">                        
                        <h2 class="title-divider">
                            <span><?php echo $link_title?></span> 
                             <?php if(!empty($link_text)){ ?><a href="<?php echo $link_url?>" class="pull-right"><?php echo $link_text?><i class="plas10"><div class="plus-up"></div><div class="plus-hor"></div></i></a> <?php } ?>
                        </h2>                       
                    </div>
                <?php }?>
            </div>
        <?php
        }

    }
}