 Volume in drive D is new disk
 Volume Serial Number is 8F44-2151

 Directory of d:\xampp\htdocs\dev\wordpress35\wp-content\plugins\revslider\js

02/21/2013  12:13 PM    <DIR>          .
02/21/2013  12:13 PM    <DIR>          ..
02/18/2013  12:53 PM            15,813 admin.js
02/21/2013  12:11 PM    <DIR>          codemirror
02/13/2013  02:18 PM            49,047 edit_layers.js
02/21/2013  12:11 PM    <DIR>          farbtastic
05/10/2012  12:18 AM             7,587 jquery.tipsy.js
02/21/2013  12:13 PM                 0 jui_old.js
02/14/2013  09:18 AM            15,176 rev_admin.js
11/04/2012  06:53 AM             5,743 settings.js
               6 File(s)         93,366 bytes
               4 Dir(s)  37,371,822,080 bytes free
